"""Top-level package for beachwatch."""

__author__ = """Ben Nour"""
__email__ = "hello@ben-nour.com"
__version__ = "0.1.3"

from .beachwatch import get_beaches, Beach
